===============
SendKeys README
===============

:Version: 0.3
:Date: 2003-06-14
:Author: Ollie Rutherfurd <oliver@rutherfurd.net>
:Homepage: http://www.rutherfurd.net/python/sendkeys/

SendKeys is a Python extension for Windows (R) which can be used to send 
one or more keystrokes or keystroke combinations to the active window.

See `doc\SendKeys.txt <doc\SendKeys.txt>`_ or 
`doc\SendKeys.html <doc\SendKeys.html>`_ for documentation.

.. :lineSeparator=\r\n:maxLineLen=72:noTabs=true:tabSize=4:wrap=hard:
